package com.movieflix.movieAPI.dto;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MovieDto {

    private Integer movieId;

    @NotBlank(message = "please provide poster's title")
    private String title;

    @NotBlank(message = "please provide director")
    private String director;

    @NotBlank(message = "please provide studio")
    private String studio;

    private Set<String> movieCast;


    private Integer releaseYear;

    @NotBlank(message = "please provide poster")
    private String poster;//basically a movie image
    @NotBlank(message = "please provide poster's url")
    private String posterUrl;


}
